package com.anthony.brightlinefold;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String HOME_URL = "https://www.gobrightline.com/";
    private static final int FILE_CHOOSER_REQUEST = 9001;

    private FrameLayout root;
    private WebView webView;
    private WebView popupWebView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> filePathCallback;

    private View pdfOverlay;
    private File currentPdfFile;
    private final ExecutorService pdfExecutor = Executors.newSingleThreadExecutor();
    private final PdfBridge pdfBridge = new PdfBridge();
    private OnBackInvokedCallback backCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = createWebView();
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        progressBar.setProgressTintList(ColorStateList.valueOf(Color.rgb(252, 217, 1)));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));

        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP);
        root.addView(progressBar, progressParams);

        setContentView(root);
        configureWindowAfterAttach();
        applySystemBarInsets();
        registerBackHandler();

        boolean restored = savedInstanceState != null && webView.restoreState(savedInstanceState) != null;
        if (!restored) {
            webView.loadUrl(HOME_URL);
        }
    }

    private void configureWindowAfterAttach() {
        root.post(() -> {
            try {
                getWindow().setStatusBarColor(Color.BLACK);
                getWindow().setNavigationBarColor(Color.BLACK);
            } catch (Throwable ignored) {
            }
        });
    }

    private void applySystemBarInsets() {
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(
                        insets.getSystemWindowInsetLeft(),
                        insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(),
                        insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        root.requestApplyInsets();
    }

    private void registerBackHandler() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            backCallback = () -> {
                if (!handleBack()) {
                    finish();
                }
            };
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    private WebView createWebView() {
        WebView view = new WebView(this);
        view.setBackgroundColor(Color.WHITE);

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(view, true);

        view.addJavascriptInterface(pdfBridge, "BrightlinePdfBridge");
        view.setWebViewClient(new BrightlineWebViewClient());
        view.setWebChromeClient(new BrightlineChromeClient());

        view.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (isPdfDownload(url, contentDisposition, mimeType)) {
                if (url != null && url.startsWith("blob:")) {
                    openBlobPdf(view, url);
                } else {
                    openPdfFromUrl(url, userAgent);
                }
            } else {
                downloadFile(url, userAgent, contentDisposition, mimeType);
            }
        });

        return view;
    }

    private final class BrightlineWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUri(view, request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUri(view, Uri.parse(url));
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            CookieManager.getInstance().flush();
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            Toast.makeText(MainActivity.this,
                    "Secure connection error. The page was blocked.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private final class BrightlineChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setProgress(newProgress);
            progressBar.setVisibility(newProgress >= 1 && newProgress <= 99 ? View.VISIBLE : View.GONE);
        }

        @Override
        public boolean onShowFileChooser(WebView webView,
                                         ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;
            try {
                startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
                return true;
            } catch (ActivityNotFoundException e) {
                filePathCallback = null;
                Toast.makeText(MainActivity.this,
                        "No file picker is available.",
                        Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        @Override
        public boolean onCreateWindow(WebView view,
                                      boolean isDialog,
                                      boolean isUserGesture,
                                      Message resultMsg) {
            Object obj = resultMsg.obj;
            if (!(obj instanceof WebView.WebViewTransport)) {
                return false;
            }

            closePopup();
            WebView popup = createWebView();
            popupWebView = popup;
            root.addView(popup, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            progressBar.bringToFront();

            WebView.WebViewTransport transport = (WebView.WebViewTransport) obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            closePopup();
        }
    }

    private boolean handleUri(WebView source, Uri uri) {
        if (uri == null || uri.getScheme() == null) {
            return false;
        }

        String scheme = uri.getScheme().toLowerCase();
        if ("http".equals(scheme) || "https".equals(scheme)) {
            String path = uri.getPath();
            if (path != null && path.toLowerCase().endsWith(".pdf")) {
                openPdfFromUrl(uri.toString(), source.getSettings().getUserAgentString());
                return true;
            }
            return false;
        }

        if ("about".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme)) {
            return false;
        }

        if ("intent".equals(scheme)) {
            return handleIntentUri(source, uri);
        }

        launchExternal(uri);
        return true;
    }

    private boolean handleIntentUri(WebView source, Uri uri) {
        try {
            Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setComponent(null);
            intent.setSelector(null);

            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                String fallback = intent.getStringExtra("browser_fallback_url");
                if (fallback != null &&
                        (fallback.startsWith("https://") || fallback.startsWith("http://"))) {
                    source.loadUrl(fallback);
                } else {
                    Toast.makeText(this,
                            "The required app is not installed.",
                            Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    private void launchExternal(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this,
                    "No installed app can open this link.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPdfDownload(String url, String contentDisposition, String mimeType) {
        String mime = mimeType == null ? "" : mimeType.toLowerCase();
        String disposition = contentDisposition == null ? "" : contentDisposition.toLowerCase();
        String path = "";
        try {
            Uri uri = Uri.parse(url);
            String segment = uri.getLastPathSegment();
            if (segment != null) path = segment.toLowerCase();
        } catch (Exception ignored) {
        }
        return mime.contains("application/pdf") ||
                mime.endsWith("/pdf") ||
                disposition.contains(".pdf") ||
                path.endsWith(".pdf");
    }

    private void openBlobPdf(WebView source, String blobUrl) {
        Toast.makeText(this, "Opening ticket…", Toast.LENGTH_SHORT).show();
        String quoted = JSONObject.quote(blobUrl);
        String js = "(async()=>{try{" +
                "const r=await fetch(" + quoted + ");" +
                "const b=await r.blob();" +
                "const fr=new FileReader();" +
                "fr.onload=()=>BrightlinePdfBridge.openPdfBase64(String(fr.result));" +
                "fr.onerror=()=>BrightlinePdfBridge.pdfError('Unable to read ticket PDF');" +
                "fr.readAsDataURL(b);" +
                "}catch(e){BrightlinePdfBridge.pdfError(String(e));}})();";
        source.evaluateJavascript(js, null);
    }

    private final class PdfBridge {
        @JavascriptInterface
        public void openPdfBase64(String dataUrl) {
            if (dataUrl == null) return;
            int comma = dataUrl.indexOf(',');
            if (comma < 0) {
                pdfError("Invalid PDF data");
                return;
            }

            String meta = dataUrl.substring(0, comma).toLowerCase();
            if (!meta.contains("base64")) {
                pdfError("Unsupported PDF data");
                return;
            }

            String payload = dataUrl.substring(comma + 1);
            pdfExecutor.execute(() -> {
                try {
                    byte[] bytes = Base64.getDecoder().decode(payload);
                    File file = new File(getCacheDir(),
                            "brightline_ticket_" + System.currentTimeMillis() + ".pdf");
                    try (FileOutputStream output = new FileOutputStream(file)) {
                        output.write(bytes);
                    }
                    if (!looksLikePdf(file)) {
                        file.delete();
                        throw new IllegalStateException("The ticket response was not a PDF");
                    }
                    runOnUiThread(() -> showPdfOverlay(file));
                } catch (Exception e) {
                    pdfError(e.getMessage() == null ? "Could not open ticket PDF" : e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void pdfError(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "Could not open ticket PDF: " + message,
                    Toast.LENGTH_LONG).show());
        }
    }

    private void openPdfFromUrl(String urlString, String userAgent) {
        if (urlString == null || urlString.isEmpty()) return;

        Toast.makeText(this, "Opening ticket…", Toast.LENGTH_SHORT).show();

        final String cookies = CookieManager.getInstance().getCookie(urlString);
        final String referer = webView.getUrl() == null ? HOME_URL : webView.getUrl();

        pdfExecutor.execute(() -> {
            HttpURLConnection connection = null;
            File pdfFile = null;
            try {
                pdfFile = new File(getCacheDir(),
                        "brightline_ticket_" + System.currentTimeMillis() + ".pdf");

                connection = (HttpURLConnection) new URL(urlString).openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(45000);
                connection.setRequestProperty("Accept", "application/pdf,*/*");
                connection.setRequestProperty("Referer", referer);
                if (userAgent != null && !userAgent.isEmpty()) {
                    connection.setRequestProperty("User-Agent", userAgent);
                }
                if (cookies != null && !cookies.isEmpty()) {
                    connection.setRequestProperty("Cookie", cookies);
                }

                int responseCode = connection.getResponseCode();
                if (responseCode < 200 || responseCode > 299) {
                    throw new IllegalStateException("Server returned HTTP " + responseCode);
                }

                try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
                     FileOutputStream output = new FileOutputStream(pdfFile)) {
                    byte[] buffer = new byte[32768];
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        output.write(buffer, 0, read);
                    }
                }

                if (!looksLikePdf(pdfFile)) {
                    throw new IllegalStateException("The ticket response was not a PDF");
                }

                File readyFile = pdfFile;
                runOnUiThread(() -> showPdfOverlay(readyFile));
            } catch (Exception e) {
                if (pdfFile != null) pdfFile.delete();
                String message = e.getMessage() == null ? "Unknown error" : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Could not open ticket PDF: " + message,
                        Toast.LENGTH_LONG).show());
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private boolean looksLikePdf(File file) {
        if (file == null || file.length() < 5) return false;
        byte[] header = new byte[5];
        try (FileInputStream input = new FileInputStream(file)) {
            if (input.read(header) != 5) return false;
            return header[0] == '%' && header[1] == 'P' && header[2] == 'D' &&
                    header[3] == 'F' && header[4] == '-';
        } catch (Exception e) {
            return false;
        }
    }

    private void showPdfOverlay(File pdfFile) {
        closePdfOverlay();

        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.rgb(238, 238, 238));

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.rgb(238, 238, 238));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(6), dp(12), dp(6));
        toolbar.setBackgroundColor(Color.WHITE);
        toolbar.setElevation(dp(3));

        Button back = new Button(this);
        back.setText("Back");
        back.setAllCaps(false);
        back.setOnClickListener(v -> closePdfOverlay());

        TextView title = new TextView(this);
        title.setText("Brightline Ticket");
        title.setTextSize(18f);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(12), 0, dp(8), 0);

        toolbar.addView(back, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        toolbar.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(225, 225, 225));

        LinearLayout pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.VERTICAL);
        pages.setGravity(Gravity.CENTER_HORIZONTAL);
        pages.setPadding(dp(10), dp(12), dp(10), dp(24));

        TextView loading = new TextView(this);
        loading.setText("Loading ticket…");
        loading.setTextSize(17f);
        loading.setGravity(Gravity.CENTER);
        loading.setTextColor(Color.DKGRAY);
        loading.setPadding(dp(24), dp(48), dp(24), dp(48));
        pages.addView(loading, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        scroll.addView(pages, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        main.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        main.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        overlay.addView(main, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        pdfOverlay = overlay;
        currentPdfFile = pdfFile;
        overlay.bringToFront();

        overlay.post(() -> renderPdfIntoPages(overlay, pages, loading, pdfFile));
    }

    private void renderPdfIntoPages(View overlay,
                                    LinearLayout pages,
                                    TextView loading,
                                    File pdfFile) {
        int availableWidth = (overlay.getWidth() > 0
                ? overlay.getWidth()
                : getResources().getDisplayMetrics().widthPixels) - dp(20);
        int targetWidth = Math.max(dp(280), Math.min(availableWidth, 1800));

        pdfExecutor.execute(() -> {
            try (ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(
                    pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(descriptor)) {

                if (renderer.getPageCount() == 0) {
                    runOnUiThread(() -> {
                        if (pdfOverlay == overlay) loading.setText("This PDF has no pages.");
                    });
                    return;
                }

                int pageLimit = Math.min(renderer.getPageCount(), 10);
                for (int pageNumber = 0; pageNumber < pageLimit; pageNumber++) {
                    PdfRenderer.Page page = renderer.openPage(pageNumber);
                    try {
                        int width = targetWidth;
                        int height = Math.max(1,
                                Math.round(width * (page.getHeight() / (float) page.getWidth())));
                        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        bitmap.eraseColor(Color.WHITE);
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

                        runOnUiThread(() -> {
                            if (pdfOverlay != overlay) {
                                bitmap.recycle();
                                return;
                            }
                            if (loading.getParent() != null) {
                                pages.removeView(loading);
                            }
                            ImageView image = new ImageView(MainActivity.this);
                            image.setImageBitmap(bitmap);
                            image.setAdjustViewBounds(true);
                            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                            image.setBackgroundColor(Color.WHITE);
                            image.setElevation(dp(2));

                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.WRAP_CONTENT);
                            params.bottomMargin = dp(12);
                            pages.addView(image, params);
                        });
                    } finally {
                        page.close();
                    }
                }
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Unable to render PDF" : e.getMessage();
                runOnUiThread(() -> {
                    if (pdfOverlay == overlay) {
                        loading.setText("Could not display this ticket PDF.");
                        Toast.makeText(MainActivity.this,
                                "PDF error: " + message,
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private void closePdfOverlay() {
        if (pdfOverlay != null) {
            root.removeView(pdfOverlay);
            pdfOverlay = null;
        }
        if (currentPdfFile != null) {
            currentPdfFile.delete();
            currentPdfFile = null;
        }
    }

    private void downloadFile(String url,
                              String userAgent,
                              String contentDisposition,
                              String mimeType) {
        if (url == null) return;
        if (url.startsWith("blob:")) {
            Toast.makeText(this,
                    "This webpage-generated download cannot be saved directly.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        try {
            String filename = URLUtil.guessFileName(url, contentDisposition, mimeType);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(filename);
            request.setDescription("Downloading from Brightline");
            if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
            if (userAgent != null && !userAgent.isEmpty()) request.addRequestHeader("User-Agent", userAgent);

            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null && !cookies.isEmpty()) request.addRequestHeader("Cookie", cookies);

            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);

            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Downloading " + filename, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not start download.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    private void closePopup() {
        if (popupWebView == null) return;
        root.removeView(popupWebView);
        popupWebView.stopLoading();
        popupWebView.loadUrl("about:blank");
        popupWebView.destroy();
        popupWebView = null;
    }

    private boolean handleBack() {
        if (pdfOverlay != null) {
            closePdfOverlay();
            return true;
        }
        if (popupWebView != null) {
            if (popupWebView.canGoBack()) {
                popupWebView.goBack();
            } else {
                closePopup();
            }
            return true;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        if (!handleBack()) {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        if (webView != null) webView.onPause();
        if (popupWebView != null) popupWebView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (popupWebView != null) popupWebView.onResume();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        closePdfOverlay();
        pdfExecutor.shutdownNow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }

        if (popupWebView != null) popupWebView.destroy();
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
